﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectInitializerDemo
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public double Salary { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee() { EmployeeID = 101, EmployeeName = "Robert", Salary = 20987 };

            Employee emp1 = new Employee { EmployeeID = 102, EmployeeName = "John", Salary = 20000 };


        }
    }
}
