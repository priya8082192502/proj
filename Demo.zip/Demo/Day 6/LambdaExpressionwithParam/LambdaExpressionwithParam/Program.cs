﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressionwithParam
{
    public delegate void MathDelegate(int num, int pow);

    class Program
    {
        static void Main(string[] args)
        {
            MathDelegate anonymous = delegate(int num, int pow)
            {
                Console.WriteLine("Using Anonymous Method : {0} ^ {1} is = {2}", num, pow, Math.Pow(num, pow));
            };
            anonymous(3, 6);

            MathDelegate lambda = (num, pow) => Console.WriteLine("Using Lambda Expression : {0} ^ {1} is = {2}", num, pow, Math.Pow(num, pow));
            lambda(4, 4);

            Console.ReadKey();
        }
    }
}
