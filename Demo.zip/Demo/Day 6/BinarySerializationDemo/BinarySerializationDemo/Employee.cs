﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySerializationDemo
{
    [Serializable]
    public class Employee
    {
        int empID;
        [NonSerialized]
        string name;
        double sal;

        public int EmployeeID 
        { 
            get { return empID; } 
            set { empID = value; } 
        }
        
        public string EmployeeName 
        { 
            get { return name; } 
            set { name = value; } 
        }
        
        public double Salary 
        { 
            get { return sal; } 
            set { sal = value; } 
        }
    }
}
