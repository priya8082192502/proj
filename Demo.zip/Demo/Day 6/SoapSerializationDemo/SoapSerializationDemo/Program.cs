﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace SoapSerializationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee() { EmployeeID = 101, EmployeeName = "Robert", Salary = 20000 };

            FileStream fs = new FileStream("SoapSer.xml", FileMode.Create, FileAccess.Write);

            
        }
    }
}
