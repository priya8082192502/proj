﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate(10);

            cal[3] = 7655;
            cal[9] = 2334;
            cal[2] = 76767;
            //cal[12] = 6776;

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(cal[i]);
            }
        }
    }
}
