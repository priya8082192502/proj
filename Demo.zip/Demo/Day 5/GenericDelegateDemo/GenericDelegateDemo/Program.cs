﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericDelegateDemo
{
    delegate T GenericDelegate<T>(T val);
    class Program
    {
        public int Cube(int num)
        {
            return num * num * num;
        }

        public string StringOp(string str)
        {
            string result = str.ToUpper();
            StringBuilder sb = new StringBuilder();
            for (int i = result.Length-1; i >= 0 ; i--)
            {
                sb.Append(result[i]);
            }
            return sb.ToString();
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            GenericDelegate<int> delInt = new GenericDelegate<int>(p.Cube);
            Console.WriteLine(delInt(4));

            GenericDelegate<string> delStr = new GenericDelegate<string>(p.StringOp);
            Console.WriteLine(delStr(".net batch"));

            GenericDelegate<double> delDouble = new GenericDelegate<double>(Math.Sin);
            Console.WriteLine(delDouble(0.45));

        }
    }
}
