﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegate
{
    delegate void CalcDelegate(int num1, int num2);

    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate();
            CalcDelegate del = new CalcDelegate(Calculate.Subtract);
            del += new CalcDelegate(cal.Add);
            del += new CalcDelegate(cal.Multiply);
            del += new CalcDelegate(Calculate.Divide);
            del += new CalcDelegate(cal.Add);

            del(20, 5);

            Delegate[] methodlist = del.GetInvocationList();

            foreach (Delegate m in methodlist)
            {
                Console.WriteLine(m.Method);
            }

            del -= new CalcDelegate(cal.Add);
            del(45, 9);

            Console.ReadKey();
        }
    }
}
