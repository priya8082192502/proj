﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Capgemini";
            Console.WriteLine(str.ToUpper());
            object o = str;

            dynamic d = str;
            //string result = d.GetUpper(); Runtime Excption
            string result = d.ToUpper();
            Console.WriteLine(result);
        }
    }
}
