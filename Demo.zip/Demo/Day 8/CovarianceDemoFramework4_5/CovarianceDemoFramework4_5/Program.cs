﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovarianceDemoFramework4_5
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }

        public Employee(int empID, string name)
        {
            EmployeeID = empID;
            EmployeeName = name;
        }
    }

    public class Manager : Employee
    {
        public int Allowance { get; set; }

        public Manager(int empID, string name, int all)
            : base(empID, name)
        {
            EmployeeID = empID;
            EmployeeName = name;
            Allowance = all;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            IList<Manager> mgrList = new List<Manager>();

            mgrList.Add(new Manager(101, "Robert", 2000));
            mgrList.Add(new Manager(102, "Jenny", 3000));
            mgrList.Add(new Manager(103, "Jason", 2000));
            mgrList.Add(new Manager(104, "Walt", 4000));

            IEnumerable<Employee> empList = mgrList;

            foreach (Manager m in empList)
            {
                Console.WriteLine("Employee ID : " + m.EmployeeID + " Employee Name : " + m.EmployeeName + " Allowance : " + m.Allowance);
            }

        }
    }
}
