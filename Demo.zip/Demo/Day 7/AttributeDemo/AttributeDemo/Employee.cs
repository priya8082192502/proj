﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributeDemo
{
    [Author("Shital Patil", @"02/23/2017")]
    //[Author("ABC", @"02/28/2017")]
    public class Employee
    {
        public int EmployeeID { get; set; }
    }
}
