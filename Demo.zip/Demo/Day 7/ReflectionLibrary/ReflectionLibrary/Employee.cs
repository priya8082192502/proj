﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    public class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public double Salary { get; set; }

        public Employee()
        {
            EmpID = 0;
            EmpName = "";
            Salary = 0.0;
        }

        public Employee(int empID, string name, double sal)
        {
            EmpID = empID;
            EmpName = name;
            Salary = sal;
        }
    }
}
