﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace MethodInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly refAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type calc = refAssembly.GetType("ReflectionLibrary.Calculate");

            MethodInfo[] calcMethods = calc.GetMethods();

            Console.WriteLine("Number of Methods in Calculate Class : " + calcMethods.Length);
            foreach (MethodInfo m in calcMethods)
            {
                Console.WriteLine("**********Method Name : " + m.Name);
                Console.WriteLine("Contains Generic Parameters : " + m.ContainsGenericParameters);
                Console.WriteLine("Is Abstract : " + m.IsAbstract);
                Console.WriteLine("Is Constructor : " + m.IsConstructor);
                Console.WriteLine("Is Final : " + m.IsFinal);
                Console.WriteLine("Is Generic Method : " + m.IsGenericMethod);
                Console.WriteLine("Is Private : " + m.IsPrivate);
                Console.WriteLine("Is Public : " + m.IsPublic);
                Console.WriteLine("Is Static : " + m.IsStatic);
                Console.WriteLine("Is Virtual : " + m.IsVirtual);
                Console.WriteLine("Return Parameter : " + m.ReturnParameter.Name);
                Console.WriteLine("Return Type : " + m.ReturnType.Name);
                ParameterInfo[] param = m.GetParameters();
                Console.WriteLine("Number of Parameters : " + param.Length);
                foreach (ParameterInfo p in param)
                {
                    Console.WriteLine("\tParameter Name : " + p.Name);
                    Console.WriteLine("\tParameter Type : " + p.ParameterType);
                    Console.WriteLine("\tPosition : " + p.Position);
                }
                Console.WriteLine();
            }

            MethodInfo add = calc.GetMethod("Add");
            if (add != null)
            {
                object obj = refAssembly.CreateInstance("ReflectionLibrary.Calculate");
                int result = (int)add.Invoke(obj, new object[] { 20, 30 });
                Console.WriteLine("Addition : " + result);
            }

            MethodInfo subtract = calc.GetMethod("Subtract");
            if (subtract != null)
            {
                int sub = (int)subtract.Invoke(null, new object[] { 30, 20 });
                Console.WriteLine("Subtraction : " + sub);
            }
        }
    }
}
